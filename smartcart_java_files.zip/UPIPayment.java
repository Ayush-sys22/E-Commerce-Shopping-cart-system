class UPIPayment  implements  PaymentMethod {
    private String upiId;
    private String transactionId;
    
    public UPIPayment (String upiId) {
        this.upiId = upiId;
    }
    
    @Override
    public boolean processPayment (double amount) {
        System.out.println( "📱 Processing UPI payment to "  + upiId + "...");
        
        // Simulate UPI processing
        try {
            Thread.sleep(800);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Generate UPI transaction ID
        transactionId = "UPI" + System.currentTimeMillis();
        
        // Simulate 98% success rate for UPI
        if (Math.random() < 0.98) {
            System.out.println( "✅ UPI payment successful!" );
            System.out.println( "📄 UPI Transaction ID: "  + transactionId);
            return true;
        } else {
            System.out.println( "❌ UPI payment failed. Please check your UPI app." );
            return false;
        }
    }
    
    @Override
    public String getPaymentDetails () {
        return String.format( "UPI Payment - %s, Transaction ID: %s" , upiId, transactionId);
    }
    
    @Override
    public String getPaymentMethodName () {
        return "UPI";
    }
}
            
 User Management & Supporting Classes
// User class