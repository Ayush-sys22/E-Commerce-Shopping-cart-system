class SeasonalDiscountStrategy  implements  DiscountStrategy {
    private double discountPercentage;
    private String season;
    
    public SeasonalDiscountStrategy (double discountPercentage, String season) {
        this.discountPercentage = discountPercentage;
        this.season = season;
    }
    
    @Override
    public double applyDiscount (Product product, double originalPrice) {
        return originalPrice * (1 - discountPercentage / 100);
    }
    
    @Override
    public String getDiscountDescription () {
        return String.format( "%s Sale: %.0f%% off" , season, discountPercentage);
    }
}
// Bulk Discount Strategy