class CashPayment  implements  PaymentMethod {
    private double cashReceived;
    private double change;
    
    public CashPayment (double cashReceived) {
        this.cashReceived = cashReceived;
    }
    
    @Override
    public boolean processPayment (double amount) {
        if (cashReceived >= amount) {
            change = cashReceived - amount;
            System.out.println( "💵 Cash payment processed successfully" );
            if (change > 0) {
                System.out.println( "💰 Change: $"  + String.format( "%.2f", change));
            }
            return true;
        }
        System.out.println( "❌ Insufficient cash. Need $"  + String.format( "%.2f", amount - cashReceived) + " more");
        return false;
    }
    
    @Override
    public String getPaymentDetails () {
        return String.format( "Cash Payment - Received: $%.2f, Change: $%.2f" , cashReceived, change);
    }
    
    @Override
    public String getPaymentMethodName () {
        return "Cash";
    }
}
// Card Payment Implementation