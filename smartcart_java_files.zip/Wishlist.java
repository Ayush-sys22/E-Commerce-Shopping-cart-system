class Wishlist  {
    private List<Product> items;
    private User user;
    private Inventory inventory;
    
    public Wishlist (User user, Inventory inventory) {
        this.items = new ArrayList<>();
        this.user = user;
        this.inventory = inventory;
    }
    
    public void addItem(Product product) {
        if (!items.contains(product)) {
            items.add(product);
            System.out.println( "❤  Added "  + product.getName() + " to wishlist" );
        } else {
            System.out.println( "ℹ  Item already in wishlist" );
        }
    }
    
    public void removeItem (Product product) {
        if (items.remove(product)) {
            System.out.println( "💔 Removed "  + product.getName() + " from wishlist" );
        }
    }
    
    public void checkLowStockAndAutoMove () {
        Iterator<Product> iterator = items.iterator();
        while (iterator.hasNext()) {
            Product product = iterator.next();
            if (product.isLowStock() && user.getCart() != null) {
                try {
                    user.getCart().addItem(product, 1);
                    iterator.remove();
                    System.out.println( "🚨 Auto-moved "  + product.getName() + 
                                     " from wishlist to cart (low stock alert!)" );
                } catch (CartException e) {
                    System.out.println( "⚠  Cannot auto-move "  + product.getName() + ": " + e.getMessage());
                }
            }
        }
    }
    
    public List<Product> getItems () { return new ArrayList<>(items); }
    public boolean isEmpty() { return items.isEmpty(); }
}
// Inventory Management