class CardPayment  implements  PaymentMethod {
    private String cardNumber;
    private String cardType;
    private String transactionId;
    
    public CardPayment (String cardNumber, String cardType) {
        this.cardNumber = maskCardNumber(cardNumber);
        this.cardType = cardType;
    }
    
    @Override
    public boolean processPayment (double amount) {
        // Simulate card processing
        System.out.println( "💳 Processing "  + cardType + " payment..." );
        
        // Simulate processing delay
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Generate transaction ID
        transactionId = "TXN" + System.currentTimeMillis();
        
        // Simulate 95% success rate
        if (Math.random() < 0.95) {
            System.out.println( "✅ Card payment successful!" );
            System.out.println( "📄 Transaction ID: "  + transactionId);
            return true;
        } else {
            System.out.println( "❌ Card payment failed. Please try again." );
            return false;
        }
    }
    
    @Override
    public String getPaymentDetails () {
        return String.format( "%s Card Payment - %s, Transaction ID: %s" , 
                              cardType, cardNumber, transactionId);
    }
    
    @Override
    public String getPaymentMethodName () {
        return cardType + " Card";
    }
    
    private String maskCardNumber (String cardNumber) {
        if (cardNumber.length() < 4) {
            return "****";
        }
        return "****-****-****-"  + cardNumber.substring(cardNumber.length() - 4);
    }
}
// UPI Payment Implementation