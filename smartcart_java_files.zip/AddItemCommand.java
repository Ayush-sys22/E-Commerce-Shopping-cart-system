class AddItemCommand  implements  Command {
    private Cart cart;
    private Product product;
    private int quantity;
    
    public AddItemCommand (Cart cart, Product product, int quantity) {
        this.cart = cart;
        this.product = product;
        this.quantity = quantity;
    }
    
    @Override
    public void execute() {
        try {
            cart.addItem(product, quantity);
        } catch (CartException e) {
            System.out.println( "Error adding item: "  + e.getMessage());
        }
    }
    
    @Override
    public void undo() {
        cart.removeItem(product.getId());
    }
}
            
 Payment System - Polymorphism
// Payment Method Interface - Polymorphism