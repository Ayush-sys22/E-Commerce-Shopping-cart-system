class NoDiscountStrategy  implements  DiscountStrategy {
    @Override
    public double applyDiscount (Product product, double originalPrice) {
        return originalPrice;
    }
    
    @Override
    public String getDiscountDescription () {
        return "No discount" ;
    }
}
// Seasonal Discount Strategy