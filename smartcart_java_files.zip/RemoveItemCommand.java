class RemoveItemCommand  implements  Command {
    private Cart cart;
    private CartItem removedItem;
    
    public RemoveItemCommand (Cart cart, CartItem item) {
        this.cart = cart;
        this.removedItem = item;
    }
    
    @Override
    public void execute() {
        // Remove logic is handled in Cart.removeItem()
    }
    
    @Override
    public void undo() {
        // Add the item back to cart
        cart.getItems().add(removedItem);
        System.out.println( "↩  Restored "  + removedItem.getProduct().getName() + " to cart" );
    }
}
// Add Item Command