class Cart {
    private List<CartItem> items;
    private LocalDateTime lastActivity;
    private final int EXPIRY_MINUTES = 30;
    private Stack<Command> undoStack;
    private Inventory inventory;
    
    public Cart(Inventory inventory) {
        this.items = new ArrayList<>();
        this.lastActivity = LocalDateTime.now();
        this.undoStack = new Stack<>();
        this.inventory = inventory;
    }
    
    public void addItem(Product product, int quantity) throws CartException {
        updateActivity();
        
        // Check stock availability
        if (product.getStockQuantity() < quantity) {
            throw new CartException( "Insufficient stock. Available: "  + product.getStockQuantity());
        }
        
        // Check if item already exists in cart
        for (CartItem item : items) {
            if (item.getProduct().getId().equals(product.getId())) {
                int newQuantity = item.getQuantity() + quantity;
                if (product.getStockQuantity() < newQuantity) {
                    throw new CartException( "Cannot add more items. Stock limit exceeded." );
                }
                item.setQuantity(newQuantity);
                System.out.println( "✅ Updated quantity for "  + product.getName());
                return;
            }
        }
        
        // Add new item
        CartItem newItem = new CartItem(product, quantity);
        items.add(newItem);
        System.out.println( "✅ Added "  + product.getName() + " to cart" );
    }
    
    public void removeItem (String productId) {
        updateActivity();
        
        CartItem itemToRemove = null;
        for (CartItem item : items) {
            if (item.getProduct().getId().equals(productId)) {
                itemToRemove = item;
                break;
            }
        }
        
        if (itemToRemove != null) {
            // Store remove command for undo functionality
            Command removeCommand = new RemoveItemCommand( this, itemToRemove);
            undoStack.push(removeCommand);
            
            items.remove(itemToRemove);
            System.out.println( "❌ Removed "  + itemToRemove.getProduct().getName() + " from cart" );
        }
    }
    
    public void undoLastAction () {
        if (!undoStack.isEmpty()) {
            Command lastCommand = undoStack.pop();
            lastCommand.undo();
            System.out.println( "↩  Undid last action" );
        } else {
            System.out.println( "⚠  No actions to undo" );
        }
    }
    
    public void checkAndUpdateStock () {
        Iterator<CartItem> iterator = items.iterator();
        while (iterator.hasNext()) {
            CartItem item = iterator.next();
            Product product = item.getProduct();
            
            if (product.getStockQuantity() == 0) {
                System.out.println( "⚠  " + product.getName() + " is out of stock and removed from cart" );
                iterator.remove();
            } else if (product.getStockQuantity() < item.getQuantity()) {
                System.out.println( "⚠  " + product.getName() + " quantity reduced to "  + product.getStockQuantity());
                item.setQuantity(product.getStockQuantity());
            }
        }
    }
    
    public boolean isExpired () {
        return Duration.between(lastActivity, LocalDateTime.now()).toMinutes() > EXPIRY_MINUTES;
    }
    
    public void releaseExpiredItems () {
        if (isExpired()) {
            System.out.println( "⏰ Cart expired. Items released back to inventory." );
            items.clear();
            undoStack.clear();
        }
    }
    
    // Sorting functionality using Comparator
    public void sortByPrice (boolean ascending) {
        if (ascending) {
            items.sort(Comparator.comparing(CartItem::getTotalPrice));
        } else {
            items.sort(Comparator.comparing(CartItem::getTotalPrice).reversed());
        }
        System.out.println( "📊 Cart sorted by price ("  + (ascending ? "low to high"  : "high to low" ) + ")");
    }
    
    public void sortByName () {
        items.sort(Comparator.comparing(item -> item.getProduct().getName()));
        System.out.println( "📊 Cart sorted by product name" );
    }
    
    public void sortByQuantity (boolean ascending) {
        if (ascending) {
            items.sort(Comparator.comparing(CartItem::getQuantity));
        } else {
            items.sort(Comparator.comparing(CartItem::getQuantity).reversed());
        }
        System.out.println( "📊 Cart sorted by quantity" );
    }
    
    public double getTotalAmount () {
        return items.stream().mapToDouble(CartItem::getTotalPrice).sum();
    }
    
    public int getTotalItems () {
        return items.stream().mapToInt(CartItem::getQuantity).sum();
    }
    
    public boolean isEmpty() {
        return items.isEmpty();
    }
    
    private void updateActivity () {
        this.lastActivity = LocalDateTime.now();
    }
    
    // Getters
    public List<CartItem> getItems () { return new ArrayList<>(items); }
    public LocalDateTime getLastActivity () { return lastActivity; }
}
// Custom Exception for Cart operations