enum ProductCategory  {
    ELECTRONICS, CLOTHING, BOOKS, HOME, SPORTS, BEAUTY
}
            
% Discount Strategy P attern
// Strategy Pattern for Discounts