class Order {
    private String orderId;
    private List<CartItem> items;
    private double subtotal;
    private double discount;
    private double tax;
    private double total;
    private PaymentMethod paymentMethod;
    private LocalDateTime orderDate;
    private OrderStatus status;
    
    public Order(List<CartItem> items, PaymentMethod paymentMethod) {
        this.orderId = "ORD" + System.currentTimeMillis();
        this.items = new ArrayList<>(items);
        this.paymentMethod = paymentMethod;
        this.orderDate = LocalDateTime.now();
        this.status = OrderStatus.CONFIRMED;
        calculateTotals();
    }
    
    private void calculateTotals () {
        subtotal = items.stream().mapToDouble(CartItem::getTotalPrice).sum();
        discount = 0; // Calculate actual discount if needed
        tax = subtotal * 0.08; // 8% tax
        total = subtotal - discount + tax;
    }
    
    // Getters
    public String getOrderId () { return orderId; }
    public List<CartItem> getItems () { return new ArrayList<>(items); }
    public double getSubtotal () { return subtotal; }
    public double getDiscount () { return discount; }
    public double getTax() { return tax; }
    public double getTotal () { return total; }
    public PaymentMethod getPaymentMethod () { return paymentMethod; }
    public LocalDateTime getOrderDate () { return orderDate; }
    public OrderStatus getStatus () { return status; }
}
// Order Status Enum