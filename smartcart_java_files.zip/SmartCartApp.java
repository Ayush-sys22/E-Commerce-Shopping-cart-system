public class  SmartCartApp  {
    public static  void main(String[] args) {
        SmartCartSystem system = new SmartCartSystem();
        system.run();
    }
}
// Main System Controller