class CartException  extends Exception {
    public CartException (String message) {
        super(message);
    }
}
            
↺ Command P attern - Undo F unctionality
// Command Pattern for Undo functionality