class Electronics  extends Product {
    private String brand;
    private int warrantyMonths;
    
    public Electronics (String name, double basePrice, String description, 
                      int stockQuantity, String brand, int warrantyMonths) {
        super(name, basePrice, description, stockQuantity);
        this.brand = brand;
        this.warrantyMonths = warrantyMonths;
        this.category = ProductCategory.ELECTRONICS;
    }
    
    // Polymorphic implementation
    @Override
    public double getFinalPrice (DiscountStrategy discountStrategy) {
        return discountStrategy.applyDiscount( this, basePrice);
    }
    
    @Override
    public String getProductDetails () {
        return String.format( "📱 %s (%s)\nPrice: $%.2f | Stock: %d\nWarranty: %d months\n%s" ,
                name, brand, basePrice, stockQuantity, warrantyMonths, description);
    }
    
    public String getBrand () { return brand; }
    public int getWarrantyMonths () { return warrantyMonths; }
}
// Clothing Product - Inheritance