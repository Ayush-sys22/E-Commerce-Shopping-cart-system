class Inventory  {
    private Map<String, Product> products;
    private Map<ProductCategory, List<Product>> categoryMap;
    
    public Inventory () {
        this.products = new HashMap<>();
        this.categoryMap = new HashMap<>();
        initializeCategoryMap();
    }
    
    private void initializeCategoryMap () {
        for (ProductCategory category : ProductCategory.values()) {
            categoryMap.put(category, new ArrayList<>());
        }
    }
    
    public void addProduct (Product product) {
        products.put(product.getId(), product);
        categoryMap.get(product.getCategory()).add(product);
    }
    
    public Product getProduct (String productId) {
        return products.get(productId);
    }
    
    public List<Product> getAllProducts () {
        return new ArrayList<>(products.values());
    }
    
    public List<Product> getProductsByCategory (ProductCategory category) {
        return new ArrayList<>(categoryMap.get(category));
    }
    
    public List<Product> searchProducts (String keyword) {
        return products.values().stream()
                .filter(p -> p.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                           p.getDescription().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }
    
    public void updateStock (String productId, int newQuantity) {
        Product product = products.get(productId);
        if (product != null) {
            product.setStockQuantity(newQuantity);
        }
    }
}
// Recommendation Engine