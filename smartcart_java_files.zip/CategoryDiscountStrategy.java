class CategoryDiscountStrategy  implements  DiscountStrategy {
    private ProductCategory targetCategory;
    private double discountPercentage;
    
    public CategoryDiscountStrategy (ProductCategory targetCategory, double discountPercentage) {
        this.targetCategory = targetCategory;
        this.discountPercentage = discountPercentage;
    }
    
    @Override
    public double applyDiscount (Product product, double originalPrice) {
        if (product.getCategory() == targetCategory) {
            return originalPrice * (1 - discountPercentage / 100);
        }
        return originalPrice;
    }
    
    @Override
    public String getDiscountDescription () {
        return String.format( "%s category: %.0f%% off" , 
                              targetCategory.toString().toLowerCase(), discountPercentage);
    }
}
// Coupon Discount Strategy