interface  PaymentMethod  {
    boolean processPayment (double amount);
    String getPaymentDetails ();
    String getPaymentMethodName ();
}
// Cash Payment Implementation