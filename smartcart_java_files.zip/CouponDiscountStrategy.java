class CouponDiscountStrategy  implements  DiscountStrategy {
    private String couponCode;
    private double discountAmount;
    private boolean isPercentage;
    private double minPurchaseAmount;
    
    public CouponDiscountStrategy (String couponCode, double discountAmount, 
                                boolean isPercentage, double minPurchaseAmount) {
        this.couponCode = couponCode;
        this.discountAmount = discountAmount;
        this.isPercentage = isPercentage;
        this.minPurchaseAmount = minPurchaseAmount;
    }
    
    @Override
    public double applyDiscount (Product product, double originalPrice) {
        if (originalPrice >= minPurchaseAmount) {
            if (isPercentage) {
                return originalPrice * (1 - discountAmount / 100);
            } else {
                return Math.max(0, originalPrice - discountAmount);
            }
        }
        return originalPrice;
    }
    
    @Override
    public String getDiscountDescription () {
        return String.format( "Coupon %s: %s%.2f off" , 
                              couponCode, isPercentage ? "" : "$", discountAmount);
    }
}
            
 Cart Management System
// CartItem class - Composition