class OrderManager  {
    private List<Order> allOrders;
    
    public OrderManager () {
        this.allOrders = new ArrayList<>();
    }
    
    public Order createOrder (Cart cart, PaymentMethod paymentMethod) {
        if (cart.isEmpty()) {
            throw new IllegalStateException( "Cannot create order with empty cart" );
        }
        
        Order order = new Order(cart.getItems(), paymentMethod);
        allOrders.add(order);
        return order;
    }
    
    public List<Order> getAllOrders () {
        return new ArrayList<>(allOrders);
    }
}
// Receipt Generator