class Clothing  extends Product {
    private String size;
    private String color;
    
    public Clothing (String name, double basePrice, String description, 
                   int stockQuantity, String size, String color) {
        super(name, basePrice, description, stockQuantity);
        this.size = size;
        this.color = color;
        this.category = ProductCategory.CLOTHING;
    }
    
    @Override
    public double getFinalPrice (DiscountStrategy discountStrategy) {
        return discountStrategy.applyDiscount( this, basePrice);
    }
    
    @Override
    public String getProductDetails () {
        return String.format( "👕 %s\nPrice: $%.2f | Stock: %d\nSize: %s | Color: %s\n%s" ,
                name, basePrice, stockQuantity, size, color, description);
    }
    
    public String getSize() { return size; }
    public String getColor () { return color; }
}
// Book Product - Inheritance