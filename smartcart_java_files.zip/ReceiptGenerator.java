class ReceiptGenerator  {
    public String generateReceipt (Order order, User user) {
        StringBuilder receipt = new StringBuilder();
        
        receipt.append( "==========================================\n" );
        receipt.append( "           🛒  SMARTCART RECEIPT           \n" );
        receipt.append( "==========================================\n" );
        receipt.append(String.format( "Order ID: %s\n" , order.getOrderId()));
        receipt.append(String.format( "Date: %s\n" , order.getOrderDate().format(
            java.time.format.DateTimeFormatter.ofPattern( "MMM dd, yyyy HH:mm:ss" ))));
        receipt.append(String.format( "Customer: %s (%s)\n" , user.getName(), user.getEmail()));
        receipt.append( "------------------------------------------\n" );
        
        // Items
        receipt.append( "ITEMS:\n" );
        for (CartItem item : order.getItems()) {
            Product product = item.getProduct();
            receipt.append(String.format( "%-20s x%d  %8s\n" , 
                    product.getName().length() > 20 ? 
                    product.getName().substring(0, 17) + "..." : product.getName(),
                    item.getQuantity(),
                    String.format( "$%.2f", item.getTotalPrice())));
        }
        
        receipt.append( "------------------------------------------\n" );
        receipt.append(String.format( "Subtotal:          %15s\n" , 
                String.format( "$%.2f", order.getSubtotal())));
        
        if (order.getDiscount() > 0) {
            receipt.append(String.format( "Discount:          %15s\n" , 
                    String.format( "-$%.2f" , order.getDiscount())));
        }
        
        receipt.append(String.format( "Tax (8%%):          %15s\n" , 
                String.format( "$%.2f", order.getTax())));
        receipt.append( "------------------------------------------\n" );
        receipt.append(String.format( "TOTAL:             %15s\n" , 
                String.format( "$%.2f", order.getTotal())));
        receipt.append( "------------------------------------------\n" );
        
        // Payment details
        receipt.append(String.format( "Payment Method: %s\n" , 
                order.getPaymentMethod().getPaymentMethodName()));
        receipt.append(String.format( "Payment Details: %s\n" , 
                order.getPaymentMethod().getPaymentDetails()));
        
        receipt.append( "==========================================\n" );
        receipt.append( "    Thank you for shopping with us! 🎉    \n");
        receipt.append( "==========================================\n" );
        
        return receipt.toString();
    }
    
    public void printReceipt (Order order, User user) {
        String receipt = generateReceipt(order, user);
        System.out.println(receipt);
    }
    
    public void saveReceiptToFile (Order order, User user) {
        String receipt = generateReceipt(order, user);
        String filename = "receipt_"  + order.getOrderId() + ".txt";
        
        try {
            java.nio.file.Files.write(java.nio.file.Paths.get(filename), 
                    receipt.getBytes(), java.nio.file.StandardOpenOption.CREATE);
            System.out.println( "📄 Receipt saved to "  + filename);
        } catch (Exception e) {
            System.out.println( "❌ Error saving receipt: "  + e.getMessage());
        }
    }
}
            
 Architecture Summary
Design P atterns Used
Strategy P attern:  For discount calculations
Command P attern:  For undo functionality
Factory P attern:  For product cr eation
Observer P attern:  For inventory notiﬁcations
Composition P attern:  Cart has CartItemsException Handling
Custom CartException  for cart operations
Stock validation e xceptions
Payment pr ocessing e xceptions
File I/O e xceptions for r eceipt generation
Null pointer e xception handling
 Feature Demonstrations
Advanced Cart F eatures
🔄 Auto-Stock Management
Automatically adjusts cart quantities when inventory changes,
removes out- of-stock items
⏰ Cart Expiry System
Releases cart items back to inventory af ter 30 minutes of inactivity
📊 Smart Sorting
Sort cart by price, name, or quantity using Comparator interfaceSmart F eatures
💡 AI Recommendations
Suggests similar pr oducts based on category and price range
❤ Smart Wishlist
Auto-moves wishlist items to cart when stock runs low
🎯 Dynamic Pricing
Multiple discount strategies: seasonal, bulk, category -speciﬁc,
coupon-based
 SmartCart  - A compr ehensive demonstration of Object- Oriented P rogramming principles in Java
Featuring Encapsulation, Inheritance, P olymorphism, Abstraction, Design P atter ns, and A dvanced E-commer ce Featur es
Made with Genspark