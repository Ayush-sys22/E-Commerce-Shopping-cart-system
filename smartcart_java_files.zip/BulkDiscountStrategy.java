class BulkDiscountStrategy  implements  DiscountStrategy {
    private int minQuantity;
    private double discountPercentage;
    private int currentQuantity;
    
    public BulkDiscountStrategy (int minQuantity, double discountPercentage, int currentQuantity) {
        this.minQuantity = minQuantity;
        this.discountPercentage = discountPercentage;
        this.currentQuantity = currentQuantity;
    }
    
    @Override
    public double applyDiscount (Product product, double originalPrice) {
        if (currentQuantity >= minQuantity) {
            return originalPrice * (1 - discountPercentage / 100);
        }
        return originalPrice;
    }
    
    @Override
    public String getDiscountDescription () {
        return String.format( "Bulk discount: %.0f%% off for %d+ items" , 
                              discountPercentage, minQuantity);
    }
}
// Category-specific Discount Strategy