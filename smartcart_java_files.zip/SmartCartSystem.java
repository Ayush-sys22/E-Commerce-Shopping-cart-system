class SmartCartSystem  {
    private Scanner scanner;
    private User currentUser;
    private Inventory inventory;
    private RecommendationEngine recommendationEngine;
    private OrderManager orderManager;
    
    public SmartCartSystem () {
        scanner = new Scanner(System.in);
        inventory = new Inventory();
        recommendationEngine = new RecommendationEngine();
        orderManager = new OrderManager();
        initializeInventory();
    }
    
    public void run() {
        System.out.println( "🛒 Welcome to SmartCart E-commerce System!" );
        
        // User registration/login
        System.out.print( "Enter your name: " );
        String name = scanner.nextLine();
        System.out.print( "Enter your email: " );
        String email = scanner.nextLine();
        
        currentUser = new User(name, email);
        System.out.println( "Welcome "  + name + "! 🎉");
        
        while (true) {
            displayMainMenu();
            int choice = getChoice();
            
            switch (choice) {
                case 1: browseProducts(); break;
                case 2: viewCart(); break;
                case 3: manageWishlist(); break;
                case 4: checkout(); break;
                case 5: viewOrderHistory(); break;
                case 6: 
                    System.out.println( "Thank you for using SmartCart! 👋 ");
                    return;
                default: 
                    System.out.println( "Invalid choice. Please try again." );
            }
        }
    }
    
    private void initializeInventory () {
        // Add sample products
        inventory.addProduct( new Electronics( "iPhone 15" , 999.99, "Latest smartphone" , 10, "Apple", 24));
        inventory.addProduct( new Electronics( "MacBook Pro" , 2499.99, "Powerful laptop" , 5, "Apple", 12));
        inventory.addProduct( new Clothing( "Nike T-Shirt" , 29.99, "Cotton t-shirt" , 50, "L", "Blue"));
        inventory.addProduct( new Clothing( "Adidas Shoes" , 129.99, "Running shoes" , 30, "42", "Black"));
        inventory.addProduct( new Book("Java Complete Reference" , 49.99, "Programming book" , 25, "Herbert Schildt" , "McGraw-Hill" ));
    }
    
    // Additional methods for menu handling, product browsing, etc.
    private void displayMainMenu () {
        System.out.println( "\n========== SMARTCART MENU ==========" );
        System.out.println( "1. 📱 Browse Products" );
        System.out.println( "2. 🛒 View Cart" );
        System.out.println( "3. ❤  Manage Wishlist" );
        System.out.println( "4. 💳 Checkout" );
        System.out.println( "5. 📋 Order History" );
        System.out.println( "6. 🚪 Exit");
        System.out.print( "Choose an option: " );
    }
    
    private int getChoice () {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
            
 Product Classes - Inheritance & Abstraction
// Abstract Product Base Class
abstract class  Product {
    protected  String id;
    protected  String name;
    protected  double basePrice;
    protected  String description;
    protected  int stockQuantity;
    protected  ProductCategory category;
    protected  LocalDateTime lastUpdated;
    
    public Product(String name, double basePrice, String description, int stockQuantity) {
        this.id = UUID.randomUUID().toString().substring(0, 8);
        this.name = name;
        this.basePrice = basePrice;
        this.description = description;
        this.stockQuantity = stockQuantity;
        this.lastUpdated = LocalDateTime.now();
    }
    
    // Abstract method for calculating final price (polymorphism)
    public abstract  double getFinalPrice (DiscountStrategy discountStrategy);
    
    // Abstract method for product details
    public abstract  String getProductDetails ();
    
    // Encapsulation - Getters and Setters
    public String getId() { return id; }
    public String getName() { return name; }
    public double getBasePrice () { return basePrice; }
    public String getDescription () { return description; }
    public int getStockQuantity () { return stockQuantity; }
    public ProductCategory getCategory () { return category; }
    
    public void setStockQuantity (int stockQuantity) {
        this.stockQuantity = stockQuantity;
        this.lastUpdated = LocalDateTime.now();
    }
    
    public boolean isInStock () {
        return stockQuantity > 0;
    }
    
    public boolean isLowStock () {
        return stockQuantity <= 5 && stockQuantity > 0;
    }
}
// Electronics Product - Inheritance