class CartItem  {
    private Product product;
    private int quantity;
    private LocalDateTime addedTime;
    private DiscountStrategy discountStrategy;
    
    public CartItem (Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        this.addedTime = LocalDateTime.now();
        this.discountStrategy = new NoDiscountStrategy();
    }
    
    public double getTotalPrice () {
        double unitPrice = product.getFinalPrice(discountStrategy);
        return unitPrice * quantity;
    }
    
    public void setDiscountStrategy (DiscountStrategy discountStrategy) {
        this.discountStrategy = discountStrategy;
    }
    
    // Getters and setters
    public Product getProduct () { return product; }
    public int getQuantity () { return quantity; }
    public void setQuantity (int quantity) { this.quantity = quantity; }
    public LocalDateTime getAddedTime () { return addedTime; }
    public DiscountStrategy getDiscountStrategy () { return discountStrategy; }
}
// Cart class with advanced features