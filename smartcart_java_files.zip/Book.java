class Book extends Product {
    private String author;
    private String publisher;
    
    public Book(String name, double basePrice, String description, 
               int stockQuantity, String author, String publisher) {
        super(name, basePrice, description, stockQuantity);
        this.author = author;
        this.publisher = publisher;
        this.category = ProductCategory.BOOKS;
    }
    
    @Override
    public double getFinalPrice (DiscountStrategy discountStrategy) {
        return discountStrategy.applyDiscount( this, basePrice);
    }
    
    @Override
    public String getProductDetails () {
        return String.format( "📚 %s\nPrice: $%.2f | Stock: %d\nAuthor: %s | Publisher: %s\n%s" ,
                name, basePrice, stockQuantity, author, publisher, description);
    }
    
    public String getAuthor () { return author; }
    public String getPublisher () { return publisher; }
}
// Product Category Enum