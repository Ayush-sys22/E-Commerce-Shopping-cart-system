class User {
    private String userId;
    private String name;
    private String email;
    private Cart cart;
    private Wishlist wishlist;
    private List<Order> orderHistory;
    private LocalDateTime registrationDate;
    
    public User(String name, String email) {
        this.userId = UUID.randomUUID().toString().substring(0, 8);
        this.name = name;
        this.email = email;
        this.orderHistory = new ArrayList<>();
        this.registrationDate = LocalDateTime.now();
    }
    
    public void initializeCart (Inventory inventory) {
        this.cart = new Cart(inventory);
    }
    
    public void initializeWishlist (Inventory inventory) {
        this.wishlist = new Wishlist( this, inventory);
    }
    
    // Getters and setters
    public String getUserId () { return userId; }
    public String getName() { return name; }
    public String getEmail () { return email; }
    public Cart getCart() { return cart; }
    public Wishlist getWishlist () { return wishlist; }
    public List<Order> getOrderHistory () { return new ArrayList<>(orderHistory); }
    
    public void addOrder (Order order) {
        orderHistory.add(order);
    }
}
// Wishlist with auto-move functionality