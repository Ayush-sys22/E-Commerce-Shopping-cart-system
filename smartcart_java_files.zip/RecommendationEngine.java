class RecommendationEngine  {
    public List<Product> getSimilarProducts (Product product, Inventory inventory, int limit) {
        List<Product> similarProducts = inventory.getProductsByCategory(product.getCategory());
        
        // Remove the current product from recommendations
        similarProducts.removeIf(p -> p.getId().equals(product.getId()));
        
        // Sort by price similarity and return limited results
        similarProducts.sort((p1, p2) -> {
            double diff1 = Math.abs(p1.getBasePrice() - product.getBasePrice());
            double diff2 = Math.abs(p2.getBasePrice() - product.getBasePrice());
            return Double.compare(diff1, diff2);
        });
        
        return similarProducts.stream().limit(limit).collect(Collectors.toList());
    }
    
    public void displayRecommendations (Product product, Inventory inventory) {
        List<Product> recommendations = getSimilarProducts(product, inventory, 3);
        
        if (!recommendations.isEmpty()) {
            System.out.println( "\n💡 You might also like:" );
            for (int i = 0; i < recommendations.size(); i++) {
                Product rec = recommendations.get(i);
                System.out.println((i + 1) + ". " + rec.getName() + 
                                 " - $" + String.format( "%.2f", rec.getBasePrice()));
            }
        }
    }
}
            
 Order Management & Receipt Generation
// Order class