interface  DiscountStrategy  {
    double applyDiscount (Product product, double originalPrice);
    String getDiscountDescription ();
}
// No Discount Strategy